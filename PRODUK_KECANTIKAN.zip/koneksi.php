<?php

$host = "localhost";
$user = "root";
$pass = "";
$db	  = "produk_kecantikan";

$dbconnect = new mysqli("$host","$user","$pass","$db");

?>