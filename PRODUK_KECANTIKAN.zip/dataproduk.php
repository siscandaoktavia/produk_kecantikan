<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Freelancer - Produk  Kecantikan</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/foto.img" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>

<div class="container-fluid">
	<div class="row">
		<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
			<div class="position-sticky pt-3">
				<ul class="nav flex-column">
					<li class="nav-item">
						<a class="nav-link" aria-current="page" href="dashboard.php">
						<span data-feather="home"></span>
							Dashboard
						</a>
					</li>
				<li class="nav-item">
					<a class="nav-link active" href="dataproduk.php">
						<span data-feather="file"></span>
							Data Barang						
						</a>
						<a class="nav-link active" href="index.php">
                        <span data-feather="file"></span>
                            Home                     
                        </a>
					</li>
				</ul>
			</div>
		</nav>
		<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2">Data Barang</h1>
		</div>

<a href="inputproduk.php" class="btn btn-primary">Input Data</a>

	<div class="card-body">

		<table id="example1" class="table table-responsive-x1 table-hover display">
			
			<thead>
				
				<tr>
					
					<th>id</th>

					<th>Kode Barang</th>

					<th>Nama Barang</th>

					<th>Harga</th>

					<th>Stok</th>

					<th>Supplier</th>

					<th>aksi</th>

				</tr>

			</thead>

			<tbody>
				
<?php				

	include 'koneksi.php';

		$no = 1;

		$number = mysqli_query($dbconnect, "SELECT * FROM Kecantikan");



		while ($query = mysqli_fetch_assoc($number)) {

?>
	
	<form  action="" method="post">
		
		   <tr>
		   	
		   	 <td><?php echo $no++;  ?></td>

		   	 <td><?php echo $query ['Kode_Barang']  ?></td>

		   	 <td><?php echo $query ['Nama_Barang']  ?></td>

		   	 <td><?php echo $query ['Harga'] ?></td>

		   	 <td><?php echo $query ['Stok']  ?></td>

		   	 <td><?php echo $query ['Supplier']  ?></td>

		   	 <td>
		   	 	
		   	 	<a href="updateproduk.php?id=<?php echo $query ['id']?>" class="btn btn-primary">Edit</a>

		   	 	<a href="proseshapusproduk.php?id=<?php echo $query ['id']?>" class="btn btn-danger" onclick="return confirm ('Apakah Ayang yakin ingin menghapus Akuh?? dengan id <?php echo $query ['id']?>??')">Hapus</a>
		   	 </td>
		   </tr>

	</form>

<?php   }   ?>

				</tbody>
			</div>
		</div>
	</main>
	</div>
  </div>
		

 	
		<script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

		<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
 	</body>